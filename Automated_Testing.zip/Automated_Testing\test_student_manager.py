import unittest
from student_manager import StudentManager


class TestStudentManager(unittest.TestCase):

    def setUp(self):
        self.manager = StudentManager()

    def test_add_student(self):
        self.manager.add_student(1, "Renuka", 85)

        student = self.manager.get_student(1)

        self.assertEqual(student["name"], "Renuka")
        self.assertEqual(student["marks"], 85)

    def test_duplicate_student(self):
        self.manager.add_student(1, "Renuka", 85)

        with self.assertRaises(ValueError):
            self.manager.add_student(1, "Anu", 90)

    def test_get_missing_student(self):
        with self.assertRaises(KeyError):
            self.manager.get_student(99)

    def test_search_student(self):
        self.manager.add_student(1, "Renuka", 85)

        result = self.manager.search_student("renuka")

        self.assertIsNotNone(result)
        self.assertEqual(result["marks"], 85)

    def test_search_missing_student(self):
        result = self.manager.search_student("Unknown")

        self.assertIsNone(result)

    def test_update_student(self):
        self.manager.add_student(1, "Renuka", 85)

        self.manager.update_student(1, name="Renuka R", marks=90)

        student = self.manager.get_student(1)

        self.assertEqual(student["name"], "Renuka R")
        self.assertEqual(student["marks"], 90)

    def test_update_missing_student(self):
        with self.assertRaises(KeyError):
            self.manager.update_student(99, name="Test")

    def test_delete_student(self):
        self.manager.add_student(1, "Renuka", 85)

        self.manager.delete_student(1)

        with self.assertRaises(KeyError):
            self.manager.get_student(1)

    def test_delete_missing_student(self):
        with self.assertRaises(KeyError):
            self.manager.delete_student(99)

    def test_average_marks(self):
        self.manager.add_student(1, "Renuka", 80)
        self.manager.add_student(2, "Anu", 90)

        average = self.manager.calculate_average()

        self.assertEqual(average, 85)

    def test_average_empty_records(self):
        self.assertEqual(self.manager.calculate_average(), 0)

    def test_pass_result(self):
        self.manager.add_student(1, "Renuka", 75)

        self.assertEqual(self.manager.get_result(1), "Pass")

    def test_fail_result(self):
        self.manager.add_student(1, "Renuka", 35)

        self.assertEqual(self.manager.get_result(1), "Fail")

    def test_invalid_marks_below_zero(self):
        with self.assertRaises(ValueError):
            self.manager.add_student(1, "Renuka", -10)

    def test_invalid_marks_above_hundred(self):
        with self.assertRaises(ValueError):
            self.manager.add_student(1, "Renuka", 110)

    def test_invalid_marks_type(self):
        with self.assertRaises(TypeError):
            self.manager.add_student(1, "Renuka", "eighty")




    def test_student_lifecycle(self):
        self.manager.add_student(1, "Renuka", 85)

        self.manager.update_student(1, name="Renuka R", marks=90)

        student = self.manager.search_student("Renuka R")

        self.assertEqual(student["marks"], 90)
        self.assertEqual(self.manager.get_result(1), "Pass")

        self.manager.delete_student(1)

        self.assertIsNone(self.manager.search_student("Renuka R"))

    def test_multiple_students_and_average(self):
        self.manager.add_student(1, "Renuka", 80)
        self.manager.add_student(2, "Anu", 90)
        self.manager.add_student(3, "Ravi", 70)

        average = self.manager.calculate_average()

        self.assertEqual(average, 80)

        self.assertEqual(self.manager.get_result(1), "Pass")
        self.assertEqual(self.manager.get_result(2), "Pass")
        self.assertEqual(self.manager.get_result(3), "Pass")

        
if __name__ == "__main__":
    unittest.main()