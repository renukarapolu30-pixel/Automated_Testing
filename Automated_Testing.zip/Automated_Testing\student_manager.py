class StudentManager:

    def __init__(self):
        self.students = {}

    def add_student(self, student_id, name, marks):
        if student_id in self.students:
            raise ValueError("Student already exists")

        self._validate_marks(marks)

        self.students[student_id] = {
            "name": name,
            "marks": marks
        }

    def get_student(self, student_id):
        if student_id not in self.students:
            raise KeyError("Student not found")

        return self.students[student_id]

    def search_student(self, name):
        for student in self.students.values():
            if student["name"].lower() == name.lower():
                return student

        return None

    def update_student(self, student_id, name=None, marks=None):
        if student_id not in self.students:
            raise KeyError("Student not found")

        if marks is not None:
            self._validate_marks(marks)
            self.students[student_id]["marks"] = marks

        if name is not None:
            self.students[student_id]["name"] = name

    def delete_student(self, student_id):
        if student_id not in self.students:
            raise KeyError("Student not found")

        del self.students[student_id]

    def calculate_average(self):
        if not self.students:
            return 0

        total = sum(
            student["marks"]
            for student in self.students.values()
        )

        return total / len(self.students)

    def get_result(self, student_id):
        student = self.get_student(student_id)

        if student["marks"] >= 40:
            return "Pass"

        return "Fail"

    def _validate_marks(self, marks):
        if not isinstance(marks, (int, float)):
            raise TypeError("Marks must be a number")

        if marks < 0 or marks > 100:
            raise ValueError("Marks must be between 0 and 100")